using UnityEngine;
using TMPro;
using System.Collections.Generic;

public class UIManager : MonoBehaviour
{
    public static UIManager Instance;

    [Header("Diálogo")]
    public TMP_Text dialogueText;
    public GameObject continueButton; // Botón "Continuar"

    [Header("Paneles de opciones")]
    public Transform questionPanel;  // Verde  - QUEST
    public Transform documentPanel; // Morado - DOC
    public Transform decisionPanel; // Naranja - DEC

    [Header("Prefabs")]
    public ChoiceButton choiceButtonPrefab;

    private List<ChoiceButton> _activeButtons = new();

    void Awake()
    {
        if (Instance == null) Instance = this;
        else Destroy(gameObject);
    }

    void Start()
    {
        DialogueManager.Instance.OnNewText += HandleNewText;
        DialogueManager.Instance.OnChoicesReady += HandleChoices;
        DialogueManager.Instance.OnDayEnd += HandleDayEnd;
    }

    private void HandleNewText(string text)
    {
        dialogueText.text = text;
        ClearButtons();
        continueButton.SetActive(true);
    }

    private void HandleChoices(List<InkChoice> choices)
    {
        continueButton.SetActive(false);
        ClearButtons();

        foreach (var choice in choices)
        {
            Transform parent = choice.Type switch
            {
                ChoiceType.Question => questionPanel,
                ChoiceType.Document => documentPanel,
                ChoiceType.Decision => decisionPanel,
                _ => questionPanel
            };

            var btn = Instantiate(choiceButtonPrefab, parent);
            btn.Setup(choice);
            _activeButtons.Add(btn);
        }
    }

    public void OnChoiceSelected(InkChoice choice)
    {
        switch (choice.Type)
        {
            case ChoiceType.Question:
                // Desactiva todas las preguntas, solo se hace una
                foreach (var btn in _activeButtons)
                    if (btn.ChoiceData.Type == ChoiceType.Question)
                        btn.SetInteractable(false);
                break;

            case ChoiceType.Document:
                // Los documentos no bloquean nada, Ink los mantiene disponibles
                break;

            case ChoiceType.Decision:
                // Limpia todo, la historia avanza al siguiente NPC
                ClearButtons();
                break;
        }

        DialogueManager.Instance.ChooseOption(choice.Index);
    }

    // Botón "Continuar" en escena llama a esto
    public void OnContinuePressed()
    {
        //continueButton.SetActive(false);
        DialogueManager.Instance.Continue();
    }

    private void HandleDayEnd()
    {
        ClearButtons();
        continueButton.SetActive(false);
        Debug.Log("[UIManager] Día completado.");
        // TODO: mostrar pantalla entre días, avanzar al siguiente
    }

    private void ClearButtons()
    {
        foreach (var btn in _activeButtons)
            if (btn != null) Destroy(btn.gameObject);
        _activeButtons.Clear();
    }
}